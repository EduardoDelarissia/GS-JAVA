package br.com.fiap.alertacidade.controller;

import br.com.fiap.alertacidade.bo.AlertaBO;
import br.com.fiap.alertacidade.dto.AlertaRequest;
import br.com.fiap.alertacidade.model.Alerta;
import br.com.fiap.alertacidade.model.StatusAlerta;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/alertas")
public class AlertaController {

    private final AlertaBO alertaBO;

    public AlertaController(AlertaBO alertaBO) {
        this.alertaBO = alertaBO;
    }

    /** GET /api/alertas?status=ABERTO&pontoId=... */
    @GetMapping
    public List<Alerta> listar(@RequestParam(name = "status", required = false) StatusAlerta status,
                               @RequestParam(name = "pontoId", required = false) Long pontoId) {
        return alertaBO.listar(status, pontoId);
    }

    @GetMapping("/{id}")
    public Alerta buscar(@PathVariable("id") Long id) {
        return alertaBO.buscar(id);
    }

    /** Alerta manual. Alertas automaticos sao criados por POST /api/medicoes. */
    @PostMapping
    public ResponseEntity<Alerta> cadastrar(@Valid @RequestBody AlertaRequest req) {
        Alerta criado = alertaBO.cadastrarManual(req);
        URI local = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(criado.getId()).toUri();
        return ResponseEntity.created(local).body(criado);
    }

    /** Atualiza nivel/mensagem; status=ENCERRADO encerra, status=ABERTO reabre. */
    @PutMapping("/{id}")
    public Alerta atualizar(@PathVariable("id") Long id, @Valid @RequestBody AlertaRequest req) {
        return alertaBO.atualizar(id, req);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable("id") Long id) {
        alertaBO.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
