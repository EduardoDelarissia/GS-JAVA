package br.com.fiap.alertacidade.model;

public enum StatusSensor {
    ATIVO,
    INATIVO,
    MANUTENCAO
}
