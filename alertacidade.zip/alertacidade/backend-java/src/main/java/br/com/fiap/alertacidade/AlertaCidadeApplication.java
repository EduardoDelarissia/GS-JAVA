package br.com.fiap.alertacidade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlertaCidadeApplication {

    public static void main(String[] args) {
        SpringApplication.run(AlertaCidadeApplication.class, args);
    }
}
