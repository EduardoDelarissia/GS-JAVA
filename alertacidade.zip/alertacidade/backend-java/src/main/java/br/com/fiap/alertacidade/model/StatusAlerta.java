package br.com.fiap.alertacidade.model;

public enum StatusAlerta {
    ABERTO,
    ENCERRADO
}
