package br.com.fiap.alertacidade.model;

public enum OrigemMedicao {
    SIMULADOR,
    MANUAL
}
